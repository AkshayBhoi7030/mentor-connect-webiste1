import sqlite3
import pandas as pd

# --- Database Path ---
db_path = "mentor_connect.db"

# --- Connect to DB ---
conn = sqlite3.connect(db_path)
cursor = conn.cursor()

# --- Get list of all tables in the DB ---
cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
tables = [t[0] for t in cursor.fetchall()]

# --- Create a writer for Excel ---
excel_path = "mentor_connect_data.xlsx"
writer = pd.ExcelWriter(excel_path, engine="openpyxl")

# --- Export each table into a sheet ---
for table in tables:
    df = pd.read_sql_query(f"SELECT * FROM {table}", conn)
    df.to_excel(writer, sheet_name=table, index=False)
    print(f"✅ Exported: {table}")

writer.close()
conn.close()

print(f"\n🎉 All tables exported successfully to '{excel_path}'")
