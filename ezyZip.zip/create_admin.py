# create_admin.py
import sqlite3, os, sys

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "mentor_connect.db")

def ensure_tables_and_admin():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()

    # users table
    c.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            role TEXT NOT NULL CHECK(role IN ('student','mentor','admin')) DEFAULT 'student',
            bio TEXT,
            expertise TEXT,
            experience INTEGER,
            rating REAL DEFAULT 0
        )
    ''')

    # bookings table
    c.execute('''
        CREATE TABLE IF NOT EXISTS bookings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER,
            mentor_id INTEGER,
            date TEXT,
            slot TEXT,
            topic TEXT,
            video_room TEXT
        )
    ''')

    # feedback table
    c.execute('''
        CREATE TABLE IF NOT EXISTS feedback (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            booking_id INTEGER,
            student_id INTEGER,
            mentor_id INTEGER,
            rating INTEGER,
            comments TEXT
        )
    ''')

    conn.commit()

    # Insert admin only if not exists
    c.execute("SELECT id,email,role FROM users WHERE role='admin' OR email=?", ("admin@mentorconnect.com",))
    row = c.fetchone()
    if row:
        print("Admin already exists:", row)
    else:
        c.execute(
            "INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)",
            ("Admin", "admin@mentorconnect.com", "admin123", "admin")
        )
        conn.commit()
        print("✅ Admin user created: admin@mentorconnect.com / admin123")

    # print all users for verification
    c.execute("SELECT id, name, email, role FROM users")
    print("\nCurrent users:")
    for r in c.fetchall():
        print(r)

    conn.close()

if __name__ == "__main__":
    ensure_tables_and_admin()
