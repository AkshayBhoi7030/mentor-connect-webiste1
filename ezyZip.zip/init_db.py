import sqlite3
# ---------- Database Initialization ----------
def init_db():
    conn = sqlite3.connect("mentor_connect.db")
    c = conn.cursor()

    # Users table
    c.execute('''
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        role TEXT NOT NULL,
        bio TEXT,
        expertise TEXT,
        experience TEXT,
        rating REAL
    )
    ''')

    # Bookings table
    c.execute('''
    CREATE TABLE IF NOT EXISTS bookings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_id INTEGER,
        mentor_id INTEGER,
        date TEXT,
        slot TEXT,
        topic TEXT,
        video_room TEXT
    )
    ''')

    # Feedback table
    c.execute('''
    CREATE TABLE IF NOT EXISTS feedback (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        booking_id INTEGER,
        student_id INTEGER,
        mentor_id INTEGER,
        rating INTEGER,
        comments TEXT
    )
    ''')

    # Chat messages table
    c.execute('''
    CREATE TABLE IF NOT EXISTS chat_messages (
        message_id INTEGER PRIMARY KEY AUTOINCREMENT,
        sender_id INTEGER NOT NULL,
        receiver_id INTEGER NOT NULL,
        message_text TEXT NOT NULL,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
        room_id TEXT NOT NULL,
        file_path TEXT,
        file_type TEXT,
        file_name TEXT,
        FOREIGN KEY(sender_id) REFERENCES users(id),
        FOREIGN KEY(receiver_id) REFERENCES users(id)
    )
    ''')

    conn.commit()
    conn.close()
    print("Tables created successfully!")

if __name__ == "__main__":
    init_db()
