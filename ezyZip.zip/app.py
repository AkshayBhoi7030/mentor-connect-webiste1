from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify, send_from_directory
from flask_socketio import SocketIO, emit, join_room, leave_room
from werkzeug.utils import secure_filename
import os
import sqlite3
import secrets
from datetime import datetime
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import pandas as pd

app = Flask(__name__)
app.secret_key = 'your_super_secret_key_here'
socketio = SocketIO(app, cors_allowed_origins="*")

# ---------- Database Path Fix ----------
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "mentor_connect.db")

# Track online users: {user_id: {'name': str, 'rooms': set()}}
online_users = {}

# File upload configuration
UPLOAD_FOLDER = os.path.join(BASE_DIR, 'uploads')
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'pdf'}
MAX_FILE_SIZE = 5 * 1024 * 1024  # 5MB

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = MAX_FILE_SIZE

# Ensure upload folder exists
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

def db_conn():
    # Ensure folder exists (just in case)
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

# ---------- Database Initialization ----------
def init_db():
    """Create required tables if they don't exist."""
    conn = db_conn()
    c = conn.cursor()

    # users table
    c.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            role TEXT NOT NULL CHECK(role IN ('student', 'mentor', 'admin')) DEFAULT 'student',
            bio TEXT,
            expertise TEXT,
            experience INTEGER,
            rating REAL DEFAULT 0
        )
    ''')

    # bookings table
    c.execute('''
        CREATE TABLE IF NOT EXISTS bookings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER NOT NULL,
            mentor_id INTEGER NOT NULL,
            date TEXT NOT NULL,
            slot TEXT,
            topic TEXT,
            video_room TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(student_id) REFERENCES users(id),
            FOREIGN KEY(mentor_id) REFERENCES users(id)
        )
    ''')

    # feedback table
    c.execute('''
        CREATE TABLE IF NOT EXISTS feedback (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            booking_id INTEGER NOT NULL,
            student_id INTEGER NOT NULL,
            mentor_id INTEGER NOT NULL,
            rating INTEGER NOT NULL,
            comments TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(booking_id) REFERENCES bookings(id),
            FOREIGN KEY(student_id) REFERENCES users(id),
            FOREIGN KEY(mentor_id) REFERENCES users(id)
        )
    ''')

    # chat_messages table
    c.execute('''
        CREATE TABLE IF NOT EXISTS chat_messages (
            message_id INTEGER PRIMARY KEY AUTOINCREMENT,
            sender_id INTEGER NOT NULL,
            receiver_id INTEGER NOT NULL,
            message_text TEXT NOT NULL,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
            room_id TEXT NOT NULL,
            file_path TEXT,
            file_type TEXT,
            file_name TEXT,
            FOREIGN KEY(sender_id) REFERENCES users(id),
            FOREIGN KEY(receiver_id) REFERENCES users(id)
        )
    ''')

    conn.commit()
    conn.close()
    print("Database initialized successfully!")

# ---------- Helpers ----------
def get_user_by_email(email):
    conn = db_conn()
    c = conn.cursor()
    c.execute("SELECT * FROM users WHERE email=?", (email,))
    user = c.fetchone()
    conn.close()
    return user

def get_user_by_id(uid):
    conn = db_conn()
    c = conn.cursor()
    c.execute("SELECT * FROM users WHERE id=?", (uid,))
    user = c.fetchone()
    conn.close()
    return user

def allowed_file(filename):
    """Check if file extension is allowed."""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def get_file_type(filename):
    """Determine file type from extension."""
    ext = filename.rsplit('.', 1)[1].lower()
    if ext in ['png', 'jpg', 'jpeg']:
        return 'image'
    elif ext == 'pdf':
        return 'document'
    return 'file'

# ---------- Public Pages ----------
@app.route('/')
def landing():
    return render_template('landing.html')

@app.route('/mentors')
def mentors():
    conn = db_conn()
    c = conn.cursor()
    c.execute("SELECT id, name, expertise, rating, bio FROM users WHERE role='mentor'")
    mentors = c.fetchall()
    conn.close()
    return render_template('mentor_list.html', mentors=mentors)

# ---------- Auth ----------
@app.route('/login', methods=['GET','POST'])
def login():
    if request.method == 'POST':
        email = request.form['email'].strip()
        password = request.form['password'].strip()
        user = get_user_by_email(email)
        if user and user['password'] == password:
            session['user_id'] = user['id']
            session['role'] = user['role']
            session['name'] = user['name']
            flash("Logged in successfully", "success")
            if user['role'] == 'student':
                return redirect(url_for('student_dashboard'))
            elif user['role'] == 'mentor':
                return redirect(url_for('mentor_dashboard'))
            else:
                return redirect(url_for('admin'))
        else:
            flash("Invalid credentials", "danger")
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    flash("Logged out", "info")
    return redirect(url_for('landing'))

@app.route('/register/student', methods=['GET','POST'])
def register_student():
    if request.method == 'POST':
        name = request.form['name'].strip()
        email = request.form['email'].strip()
        password = request.form['password'].strip()
        skills = request.form.get('skills','').strip()
        conn = db_conn()
        c = conn.cursor()
        try:
            c.execute("INSERT INTO users (name,email,password,role,bio,expertise) VALUES (?,?,?,?,?,?)",
                      (name,email,password,'student', '', skills))
            conn.commit()
            flash("Registered as student. Please login.", "success")
            return redirect(url_for('login'))
        except Exception as e:
            flash("Error: " + str(e), "danger")
        finally:
            conn.close()
    return render_template('register_student.html')

@app.route('/register/mentor', methods=['GET','POST'])
def register_mentor():
    if request.method == 'POST':
        name = request.form['name'].strip()
        email = request.form['email'].strip()
        password = request.form['password'].strip()
        expertise = request.form.get('expertise','').strip()
        experience = request.form.get('experience','').strip()
        bio = request.form.get('bio','').strip()
        conn = db_conn()
        c = conn.cursor()
        try:
            c.execute("INSERT INTO users (name,email,password,role,bio,expertise,experience) VALUES (?,?,?,?,?,?,?)",
                      (name,email,password,'mentor', bio, expertise, experience))
            conn.commit()
            flash("Registered as mentor. Please login.", "success")
            return redirect(url_for('login'))
        except Exception as e:
            flash("Error: " + str(e), "danger")
        finally:
            conn.close()
    return render_template('register_mentor.html')

@app.route('/student/dashboard')
def student_dashboard():
    if 'user_id' not in session or session.get('role') != 'student':
        return redirect(url_for('login'))

    uid = session['user_id']
    conn = db_conn()
    c = conn.cursor()

    c.execute("""
        SELECT b.*, u.name as mentor_name
        FROM bookings b
        JOIN users u ON u.id = b.mentor_id
        WHERE b.student_id = ?
    """, (uid,))

    bookings = c.fetchall()
    conn.close()

    return render_template('student_dashboard.html', bookings=bookings)


# ---------- Mentor Dashboard ----------
@app.route('/mentor/dashboard')
def mentor_dashboard():
    if 'user_id' not in session or session.get('role') != 'mentor':
        return redirect(url_for('login'))
    uid = session['user_id']
    conn = db_conn()
    c = conn.cursor()
    
    # Get all bookings for sessions table
    c.execute("""
        SELECT b.id, b.date, b.slot, b.topic, u.name as mentee_name,
               CASE 
                   WHEN date(b.date) > date('now') THEN 'confirmed'
                   WHEN date(b.date) = date('now') THEN 'pending'
                   ELSE 'completed'
               END as status,
               b.video_room
        FROM bookings b 
        JOIN users u ON u.id = b.student_id 
        WHERE b.mentor_id = ?
        ORDER BY b.date DESC
    """, (uid,))
    bookings_raw = c.fetchall()
    
    # Convert to list of dicts for template
    sessions = [{
        'id': b['id'],
        'mentee_name': b['mentee_name'],
        'date': b['date'],
        'slot': b['slot'] or 'Not set',
        'topic': b['topic'] or 'General mentoring',
        'status': b['status'],
        'video_room': b['video_room']
    } for b in bookings_raw]
    
    # Get unique mentees with last session date
    c.execute("""
        SELECT DISTINCT u.id, u.name, 
               MAX(b.date) as last_session_date
        FROM users u
        JOIN bookings b ON b.student_id = u.id
        WHERE b.mentor_id = ?
        GROUP BY u.id, u.name
        ORDER BY last_session_date DESC
    """, (uid,))
    mentees_raw = c.fetchall()
    
    mentees = [{
        'id': m['id'],
        'name': m['name'],
        'avatar': None,  # Can be added later from user profile
        'last_session_date': m['last_session_date'] or 'No sessions yet'
    } for m in mentees_raw]
    
    # Calculate statistics
    c.execute("SELECT COUNT(*) as total FROM bookings WHERE mentor_id=?", (uid,))
    total_sessions = c.fetchone()['total']
    
    c.execute("SELECT COUNT(*) as upcoming FROM bookings WHERE mentor_id=? AND date(date) >= date('now')", (uid,))
    upcoming_sessions = c.fetchone()['upcoming']
    
    c.execute("SELECT AVG(rating) as avg_rating FROM feedback WHERE mentor_id=?", (uid,))
    avg_rating_row = c.fetchone()
    avg_rating = avg_rating_row['avg_rating'] if avg_rating_row['avg_rating'] else 0.0
    
    # Pending requests (bookings within next 7 days)
    c.execute("SELECT COUNT(*) as pending FROM bookings WHERE mentor_id=? AND date(date) BETWEEN date('now') AND date('now', '+7 days')", (uid,))
    pending_requests = c.fetchone()['pending']
    
    stats = {
        'total_sessions': total_sessions,
        'upcoming_sessions': upcoming_sessions,
        'avg_rating': avg_rating,
        'pending_requests': pending_requests
    }
    
    # Mock notifications (can be replaced with real notification system)
    notifications = [
        {
            'title': 'New Session Request',
            'message': 'You have a new session request for tomorrow',
            'time': '2 hours ago',
            'action_url': url_for('mentor_dashboard')
        }
    ] if pending_requests > 0 else []
    
    conn.close()
    
    return render_template('mentor_dashboard.html', 
                         sessions=sessions,
                         mentees=mentees,
                         stats=stats,
                         notifications=notifications)

# Placeholder routes for mentor dashboard actions
@app.route('/mentor/create-session')
def create_session():
    """Placeholder for creating a new session."""
    flash("Create Session feature - Coming soon!", "info")
    return redirect(url_for('mentor_dashboard'))

@app.route('/mentor/calendar')
def calendar():
    """Placeholder for calendar view."""
    flash("Calendar view - Coming soon!", "info")
    return redirect(url_for('mentor_dashboard'))

@app.route('/mentor/profile')
def mentor_profile():
    """Placeholder for mentor profile."""
    flash("Profile editor - Coming soon!", "info")
    return redirect(url_for('mentor_dashboard'))

@app.route('/session/start/<int:session_id>')
def start_session(session_id):
    """Start a session (redirect to video call)."""
    return redirect(url_for('video_call', booking_id=session_id))

@app.route('/session/reschedule/<int:session_id>')
def reschedule_session(session_id):
    """Placeholder for rescheduling a session."""
    flash("Reschedule feature - Coming soon!", "info")
    return redirect(url_for('mentor_dashboard'))

@app.route('/session/cancel/<int:session_id>')
def cancel_session(session_id):
    """Cancel a session."""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    conn = db_conn()
    c = conn.cursor()
    c.execute("DELETE FROM bookings WHERE id=? AND mentor_id=?", (session_id, session['user_id']))
    conn.commit()
    conn.close()
    
    flash("Session cancelled successfully.", "success")
    return redirect(url_for('mentor_dashboard'))

@app.route('/mentee/<int:mentee_id>')
def view_mentee(mentee_id):
    """View mentee details."""
    flash("Mentee details - Coming soon!", "info")
    return redirect(url_for('mentor_dashboard'))

@app.route('/mentor/mentees')
def all_mentees():
    """List all mentees."""
    flash("All mentees list - Coming soon!", "info")
    return redirect(url_for('mentor_dashboard'))

@app.route('/mentor/find-mentees')
def find_mentees():
    """Find new mentees."""
    flash("Find mentees feature - Coming soon!", "info")
    return redirect(url_for('mentor_dashboard'))

@app.route('/notifications')
def all_notifications():
    """View all notifications."""
    flash("Notifications page - Coming soon!", "info")
    return redirect(url_for('mentor_dashboard'))

# ---------- Booking Flow ----------
@app.route('/book/<int:mentor_id>', methods=['GET','POST'])
def book_session(mentor_id):
    if 'user_id' not in session or session.get('role') != 'student':
        flash("Please login as a student to book", "warning")
        return redirect(url_for('login'))

    mentor = get_user_by_id(mentor_id)
    if not mentor:
        flash("Mentor not found", "danger")
        return redirect(url_for('mentors'))

    if request.method == 'POST':
        date = request.form['date']
        slot = request.form['slot']
        topic = request.form['topic']
        student_id = session['user_id']
        conn = db_conn()
        c = conn.cursor()

        room = "room_" + secrets.token_hex(6)
        c.execute("INSERT INTO bookings (student_id,mentor_id,date,slot,topic,video_room) VALUES (?,?,?,?,?,?)",
                  (student_id, mentor_id, date, slot, topic, room))
        conn.commit()
        conn.close()
        flash("Session booked! You can join from dashboard at scheduled time.", "success")
        return redirect(url_for('student_dashboard'))

    # For demo: provide some default slots
    slots = ["10:00 AM - 10:30 AM", "11:00 AM - 11:30 AM", "04:00 PM - 04:30 PM"]
    return render_template('book_session.html', mentor=mentor, slots=slots)

# ---------- Video Call (demo with embed) ----------
@app.route('/video/<int:booking_id>')
def video_call(booking_id):
    if 'user_id' not in session:
        flash("Please login to join", "warning")
        return redirect(url_for('login'))
    conn = db_conn()
    c = conn.cursor()
    c.execute("SELECT * FROM bookings WHERE id=?", (booking_id,))
    booking = c.fetchone()
    conn.close()
    if not booking:
        flash("Booking not found", "danger")
        return redirect(url_for('student_dashboard'))
    return render_template('video_call.html', booking=booking)

# ---------- Feedback ----------
@app.route('/feedback/<int:booking_id>', methods=['GET','POST'])
def feedback(booking_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    if request.method == 'POST':
        rating = int(request.form['rating'])
        comments = request.form.get('comments','').strip()
        student_id = session['user_id']
        conn = db_conn()
        c = conn.cursor()
        c.execute("SELECT mentor_id FROM bookings WHERE id=?", (booking_id,))
        mentor_row = c.fetchone()
        if mentor_row:
            mentor_id = mentor_row['mentor_id']
            c.execute("INSERT INTO feedback (booking_id, student_id, mentor_id, rating, comments) VALUES (?,?,?,?,?)",
                      (booking_id, student_id, mentor_id, rating, comments))
            # update mentor average rating (simple approach)
            c.execute("SELECT AVG(rating) as avg FROM feedback WHERE mentor_id=?", (mentor_id,))
            avg = c.fetchone()['avg'] or 0
            c.execute("UPDATE users SET rating=? WHERE id=?", (avg, mentor_id))
            conn.commit()
        conn.close()
        flash("Thanks for the feedback!", "success")
        return redirect(url_for('student_dashboard'))
    return render_template('feedback.html', booking_id=booking_id)

# ---------- Admin ----------
@app.route('/admin')
def admin():
    if 'user_id' not in session or session.get('role') != 'admin':
        flash("Access denied. Admins only.", "danger")
        return redirect(url_for('login'))

    conn = db_conn()
    c = conn.cursor()
    c.execute("SELECT id,name,email,role,expertise,experience,rating FROM users")
    users = c.fetchall()
    conn.close()
    return render_template('admin.html', users=users)


# ---------- Simple AI-match placeholder ----------
@app.route('/match', methods=['POST'])
def ai_match():
    # Demo: receives skills, returns top mentors by simple keyword match
    skills = request.form.get('skills','').lower().split(',')
    conn = db_conn()
    c = conn.cursor()
    c.execute("SELECT id,name,expertise,rating FROM users WHERE role='mentor'")
    mentors = c.fetchall()
    scored = []
    for m in mentors:
        exp = (m['expertise'] or '').lower()
        score = sum(1 for s in skills if s.strip() and s.strip() in exp)
        scored.append((m, score))
    scored.sort(key=lambda x: (-x[1], - (x[0]['rating'] or 0)))
    top = [row[0] for row in scored[:10]]
    conn.close()
    # Render mentor list with recommended flag
    return render_template('mentor_list.html', mentors=top, recommended=True)
# ---------- AI Mentor Recommendation ----------
def recommend_mentors(student_id, top_n=5):
    """Return top mentors for a given student using TF-IDF + cosine similarity."""
    conn = db_conn()
    c = conn.cursor()

    # get student data
    c.execute("SELECT * FROM users WHERE id=? AND role='student'", (student_id,))
    student = c.fetchone()
    if not student:
        conn.close()
        return []

    # get mentors
    c.execute("SELECT * FROM users WHERE role='mentor'")
    mentors = c.fetchall()
    if not mentors:
        conn.close()
        return []

    # prepare mentor and student text corpus
    mentor_texts = [f"{m['expertise']} {m['bio']} {m['experience']}" for m in mentors]
    student_profile = f"{student['bio']} {student['expertise'] or ''}"

    corpus = mentor_texts + [student_profile]

    vectorizer = TfidfVectorizer(stop_words='english')
    tfidf = vectorizer.fit_transform(corpus)

    student_vec = tfidf[-1]
    mentor_vecs = tfidf[:-1]
    sims = cosine_similarity(student_vec, mentor_vecs).flatten()

    df = pd.DataFrame({
        'id': [m['id'] for m in mentors],
        'name': [m['name'] for m in mentors],
        'expertise': [m['expertise'] for m in mentors],
        'rating': [m['rating'] for m in mentors],
        'similarity': sims
    })

    df = df.sort_values(by=['similarity', 'rating'], ascending=False).head(top_n)
    conn.close()
    return df.to_dict(orient='records')


# ---------- Chat API Routes ----------
@app.route('/api/chat/history/<room_id>')
def get_chat_history(room_id):
    """Get chat history for a specific room."""
    if 'user_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    conn = db_conn()
    c = conn.cursor()
    c.execute("""
        SELECT cm.message_id, cm.sender_id, cm.receiver_id, cm.message_text, 
               cm.timestamp, cm.file_path, cm.file_type, cm.file_name, u.name as sender_name
        FROM chat_messages cm
        JOIN users u ON u.id = cm.sender_id
        WHERE cm.room_id = ?
        ORDER BY cm.timestamp ASC
    """, (room_id,))
    
    messages = c.fetchall()
    conn.close()
    
    return jsonify([
        {
            'message_id': msg['message_id'],
            'sender_id': msg['sender_id'],
            'sender_name': msg['sender_name'],
            'receiver_id': msg['receiver_id'],
            'message_text': msg['message_text'],
            'timestamp': msg['timestamp'],
            'file_path': msg['file_path'],
            'file_type': msg['file_type'],
            'file_name': msg['file_name']
        }
        for msg in messages
    ])

@app.route('/api/online-users')
def get_online_users():
    """Get list of currently online user IDs."""
    if 'user_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    return jsonify({
        'online_users': list(online_users.keys())
    })

@app.route('/api/upload-file', methods=['POST'])
def upload_file():
    """Handle file uploads for chat."""
    if 'user_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    if 'file' not in request.files:
        return jsonify({'error': 'No file provided'}), 400
    
    file = request.files['file']
    room_id = request.form.get('room_id')
    receiver_id = request.form.get('receiver_id')
    
    if file.filename == '':
        return jsonify({'error': 'No file selected'}), 400
    
    if not allowed_file(file.filename):
        return jsonify({'error': 'File type not allowed. Only PNG, JPG, JPEG, and PDF are supported.'}), 400
    
    try:
        # Secure the filename and add timestamp to avoid collisions
        original_filename = secure_filename(file.filename)
        filename = f"{secrets.token_hex(8)}_{original_filename}"
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        
        # Save file
        file.save(filepath)
        
        # Get file info
        file_type = get_file_type(original_filename)
        sender_id = session.get('user_id')
        sender_name = session.get('name', 'Anonymous')
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        message_text = f"Shared a {file_type}: {original_filename}"
        
        # Save to database
        conn = db_conn()
        c = conn.cursor()
        c.execute("""
            INSERT INTO chat_messages (sender_id, receiver_id, message_text, timestamp, room_id, file_path, file_type, file_name)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (sender_id, receiver_id, message_text, timestamp, room_id, filename, file_type, original_filename))
        
        message_id = c.lastrowid
        conn.commit()
        conn.close()
        
        return jsonify({
            'success': True,
            'message_id': message_id,
            'sender_id': sender_id,
            'sender_name': sender_name,
            'receiver_id': receiver_id,
            'message_text': message_text,
            'timestamp': timestamp,
            'file_path': filename,
            'file_type': file_type,
            'file_name': original_filename,
            'room_id': room_id
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/uploads/<filename>')
def serve_file(filename):
    """Serve uploaded files securely."""
    if 'user_id' not in session:
        return "Unauthorized", 401
    
    # Verify the file exists in database and user has access
    conn = db_conn()
    c = conn.cursor()
    user_id = session.get('user_id')
    
    c.execute("""
        SELECT * FROM chat_messages 
        WHERE file_path = ? AND (sender_id = ? OR receiver_id = ?)
    """, (filename, user_id, user_id))
    
    message = c.fetchone()
    conn.close()
    
    if not message:
        return "File not found or access denied", 404
    
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

# ---------- SocketIO Chat Handlers ----------
@socketio.on('connect')
def on_connect():
    """Handle user connection."""
    user_id = session.get('user_id')
    username = session.get('name', 'Anonymous')
    
    if user_id:
        if user_id not in online_users:
            online_users[user_id] = {'name': username, 'rooms': set()}
        print(f"User {username} (ID: {user_id}) connected")

@socketio.on('disconnect')
def on_disconnect():
    """Handle user disconnection."""
    user_id = session.get('user_id')
    username = session.get('name', 'Anonymous')
    
    if user_id and user_id in online_users:
        # Notify all rooms the user was in
        for room in online_users[user_id]['rooms']:
            emit('user_status', {
                'user_id': user_id,
                'username': username,
                'status': 'offline'
            }, room=room)
        
        del online_users[user_id]
        print(f"User {username} (ID: {user_id}) disconnected")

@socketio.on('join')
def on_join(data):
    """Handle user joining a chat room."""
    room = data.get('room')
    username = session.get('name', 'Anonymous')
    user_id = session.get('user_id')
    
    if room and user_id:
        join_room(room)
        
        # Track the room
        if user_id not in online_users:
            online_users[user_id] = {'name': username, 'rooms': set()}
        online_users[user_id]['rooms'].add(room)
        
        # Notify room that user is online
        emit('user_status', {
            'user_id': user_id,
            'username': username,
            'status': 'online'
        }, room=room)
        
        emit('status', {
            'msg': f'{username} has entered the room.',
            'user_id': user_id
        }, room=room)

@socketio.on('leave')
def on_leave(data):
    """Handle user leaving a chat room."""
    room = data.get('room')
    username = session.get('name', 'Anonymous')
    user_id = session.get('user_id')
    
    if room and user_id:
        leave_room(room)
        
        # Remove room from tracking
        if user_id in online_users and room in online_users[user_id]['rooms']:
            online_users[user_id]['rooms'].remove(room)
        
        # Notify room that user left
        emit('user_status', {
            'user_id': user_id,
            'username': username,
            'status': 'offline'
        }, room=room)
        
        emit('status', {
            'msg': f'{username} has left the room.',
            'user_id': user_id
        }, room=room)

@socketio.on('typing')
def on_typing(data):
    """Handle typing indicator."""
    room = data.get('room')
    user_id = session.get('user_id')
    username = session.get('name', 'Anonymous')
    is_typing = data.get('is_typing', False)
    
    if room and user_id:
        # Broadcast to others in the room (not to self)
        emit('user_typing', {
            'user_id': user_id,
            'username': username,
            'is_typing': is_typing
        }, room=room, include_self=False)

@socketio.on('send_message')
def handle_message(data):
    """Handle incoming chat messages and save to database."""
    room = data.get('room')
    message = data.get('message')
    sender_id = session.get('user_id')
    sender_name = session.get('name', 'Anonymous')
    receiver_id = data.get('receiver_id')
    
    if not all([room, message, sender_id, receiver_id]):
        return
    
    # Save message to database
    conn = db_conn()
    c = conn.cursor()
    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    
    c.execute("""
        INSERT INTO chat_messages (sender_id, receiver_id, message_text, timestamp, room_id)
        VALUES (?, ?, ?, ?, ?)
    """, (sender_id, receiver_id, message, timestamp, room))
    
    message_id = c.lastrowid
    conn.commit()
    conn.close()
    
    # Broadcast message to room
    emit('receive_message', {
        'message_id': message_id,
        'sender_id': sender_id,
        'sender_name': sender_name,
        'receiver_id': receiver_id,
        'message_text': message,
        'timestamp': timestamp
    }, room=room)

# ---------- Start App ----------
if __name__ == "__main__":
    # Delete the old DB manually if you want a clean start (see instructions below)
    init_db()   # <-- important: create tables before any requests
    socketio.run(app, debug=True)
